struct _alignmapsegment;

void ProgressiveDP(struct _alignmapsegment *segment);
