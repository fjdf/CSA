
void CleanDNAFastaFile(char *fastafilename);
int CalculateSumOfPairsScore(char *fastafilename);
void TestAlignmentFileOutput(char *filename1, char *filename2);
//void CompareToReferenceAlignment(char *testfilename, char *referencefilename);
void ConvertFastaToMsf(char *fastafilename);
//void ConvertMsfToFasta(char *msffilename);
